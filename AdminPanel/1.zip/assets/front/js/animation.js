var animation = bodymovin.loadAnimation({
  container: document.getElementById("bm1"),
  renderer: "svg",
  loop: true,
  autoplay: true,
  path: assets("front/js/animation/data.json"),
});
var animation = bodymovin.loadAnimation({
  container: document.getElementById("bm2"),
  renderer: "svg",
  loop: true,
  autoplay: true,
  path: assets("front/js/animation/data.json"),
});
var animation = bodymovin.loadAnimation({
  container: document.getElementById("bm3"),
  renderer: "svg",
  loop: true,
  autoplay: true,
  path: assets("front/js/animation/data.json"),
});
var animation = bodymovin.loadAnimation({
  container: document.getElementById("bm4"),
  renderer: "svg",
  loop: true,
  autoplay: true,
  path: assets("front/js/animation/data.json"),
});
