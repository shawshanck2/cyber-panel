<style>
    .table td {
        min-width: 80px;
    }
</style>
<div class="card">
    <div class="card-header fw-bold">
        آخرین کاربران ثبت شده
    </div>
    <div class="card-body table-responsive">
        <table id="users-table" class="table " style="width: 100%;">
            <tbody>

            </tbody>
        </table>
    </div>
</div>
