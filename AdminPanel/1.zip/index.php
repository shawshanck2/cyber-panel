<?php

/**
 * By MahmoudAp
 * Github: https://github.com/mahmoud-ap
 */

define('PATH', __DIR__);

require_once 'vendor/autoload.php';
require_once 'bootstrap/bootstrap.php';
